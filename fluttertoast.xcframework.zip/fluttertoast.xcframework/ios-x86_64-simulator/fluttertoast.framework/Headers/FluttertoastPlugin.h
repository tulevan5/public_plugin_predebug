#import <Flutter/Flutter.h>

@interface FluttertoastPlugin : NSObject<FlutterPlugin>
@end
